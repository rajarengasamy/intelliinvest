-- phpMyAdmin SQL Dump
-- version 4.1.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 14, 2014 at 09:36 PM
-- Server version: 5.5.37-cll
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `intellii_qa`
--
use intelliinvest;

-- --------------------------------------------------------

--
-- Table structure for table `NIFTY_STOCKS`
--

CREATE TABLE IF NOT EXISTS `NIFTY_STOCKS` (
  `CODE` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NIFTY_STOCKS`
--

INSERT INTO `NIFTY_STOCKS` (`CODE`) VALUES
('ACC'),
('AMBUJACEM'),
('ASIANPAINT'),
('AXISBANK'),
('BAJAJ-AUTO'),
('BANKBARODA'),
('BHEL'),
('BPCL'),
('BHARTIARTL'),
('CAIRN'),
('CIPLA'),
('COALINDIA'),
('DLF'),
('DRREDDY'),
('GAIL'),
('GRASIM'),
('HCLTECH'),
('HDFCBANK'),
('HEROMOTOCO'),
('HINDALCO'),
('HINDUNILVR'),
('HDFC'),
('ITC'),
('ICICIBANK'),
('IDFC'),
('INDUSINDBK'),
('INFY'),
('JPASSOCIAT'),
('JINDALSTEL'),
('KOTAKBANK'),
('LT'),
('LUPIN'),
('M&M'),
('MARUTI'),
('NMDC'),
('NTPC'),
('ONGC'),
('POWERGRID'),
('PNB'),
('RANBAXY'),
('RELIANCE'),
('SSLT'),
('SBIN'),
('SUNPHARMA'),
('TCS'),
('TATAMOTORS'),
('TATAPOWER'),
('TATASTEEL'),
('ULTRACEMCO'),
('WIPRO');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
