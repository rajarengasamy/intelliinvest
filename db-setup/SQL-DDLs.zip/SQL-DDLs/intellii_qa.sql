-- phpMyAdmin SQL Dump
-- version 4.1.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 14, 2014 at 08:56 PM
-- Server version: 5.5.37-cll
-- PHP Version: 5.4.23

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `intellii_qa`
--
use intelliinvest;
-- --------------------------------------------------------

--
-- Table structure for table `BHAV_DATA`
--

CREATE TABLE IF NOT EXISTS `BHAV_DATA` (
  `EXCHANGE` varchar(8) NOT NULL DEFAULT '',
  `SYMBOL` varchar(20) NOT NULL DEFAULT '',
  `SERIES` varchar(4) DEFAULT NULL,
  `OPEN` double DEFAULT NULL,
  `HIGH` double DEFAULT NULL,
  `LOW` double DEFAULT NULL,
  `CLOSE` double DEFAULT NULL,
  `LAST` double DEFAULT NULL,
  `PREVCLOSE` double DEFAULT NULL,
  `TOTTRDQTY` bigint(20) DEFAULT NULL,
  `TOTTRDVAL` double DEFAULT NULL,
  `TIMESTAMP` date NOT NULL DEFAULT '0000-00-00',
  `TOTALTRADES` bigint(20) DEFAULT NULL,
  `ISIN` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`EXCHANGE`,`SYMBOL`,`TIMESTAMP`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `BOM_STOCKS`
--

CREATE TABLE IF NOT EXISTS `BOM_STOCKS` (
  `CODE` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `CHAT_DATA`
--

CREATE TABLE IF NOT EXISTS `CHAT_DATA` (
  `MESSAGE_ID` int(10) NOT NULL DEFAULT '0',
  `USERNAME` varchar(25) DEFAULT NULL,
  `CHAT_TIME` datetime DEFAULT NULL,
  `CHAT_MESSAGE` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`MESSAGE_ID`),
  KEY `IDX_CHAT_DATA_1` (`USERNAME`),
  KEY `IDX_CHAT_DATA_2` (`CHAT_TIME`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `CHAT_HISTORY`
--

CREATE TABLE IF NOT EXISTS `CHAT_HISTORY` (
  `MESSAGE_ID` int(10) NOT NULL DEFAULT '0',
  `USERNAME` varchar(25) DEFAULT NULL,
  `CHAT_TIME` datetime DEFAULT NULL,
  `CHAT_MESSAGE` varchar(500) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `CURRENT_STOCK_PRICE`
--

CREATE TABLE IF NOT EXISTS `CURRENT_STOCK_PRICE` (
  `CODE` varchar(100) NOT NULL DEFAULT '',
  `CURRENT_PRICE` double DEFAULT NULL,
  `CP` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `EOD_STOCK_PRICE`
--

CREATE TABLE IF NOT EXISTS `EOD_STOCK_PRICE` (
  `CODE` varchar(100) NOT NULL DEFAULT '',
  `EOD_DATE` date NOT NULL DEFAULT '0000-00-00',
  `EOD_PRICE` double DEFAULT NULL,
  PRIMARY KEY (`CODE`,`EOD_DATE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `INTELLI_INVEST_DATA`
--

CREATE TABLE IF NOT EXISTS `INTELLI_INVEST_DATA` (
  `CODE` varchar(100) NOT NULL DEFAULT '',
  `EOD_PRICE` double DEFAULT NULL,
  `SIGNAL_PRICE` double DEFAULT NULL,
  `YESTERDAY_SIGNAL_TYPE` varchar(15) DEFAULT NULL,
  `SIGNAL_TYPE` varchar(15) DEFAULT NULL,
  `QUARTERLY` double DEFAULT NULL,
  `HALF_YEARLY` double DEFAULT NULL,
  `NINE_MONTHS` double DEFAULT NULL,
  `YEARLY` double DEFAULT NULL,
  PRIMARY KEY (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `KEY_STORE`
--

CREATE TABLE IF NOT EXISTS `KEY_STORE` (
  `type` varchar(100) NOT NULL DEFAULT '',
  `value` int(10) DEFAULT NULL,
  PRIMARY KEY (`type`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `MANAGE_PORTFOLIO_DETAILS`
--

CREATE TABLE IF NOT EXISTS `MANAGE_PORTFOLIO_DETAILS` (
  `ID` varchar(50) NOT NULL DEFAULT '',
  `USER_ID` varchar(25) DEFAULT NULL,
  `CODE` varchar(100) DEFAULT NULL,
  `TRADE_DATE` date DEFAULT NULL,
  `DIRECTION` varchar(10) DEFAULT NULL,
  `QUANTITY` double DEFAULT NULL,
  `PRICE` double DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `IDX_MANAGE_PORTFOLIO_DETAILS_1` (`USER_ID`),
  KEY `IDX_MANAGE_PORTFOLIO_DETAILS_2` (`USER_ID`,`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NIFTY_STOCKS`
--

CREATE TABLE IF NOT EXISTS `NIFTY_STOCKS` (
  `CODE` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `NSE_TO_BSE_MAP`
--

CREATE TABLE IF NOT EXISTS `NSE_TO_BSE_MAP` (
  `NSE_CODE` varchar(100) DEFAULT NULL,
  `BSE_CODE` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `OPTION_SUGGESTIONS_DATA`
--

CREATE TABLE IF NOT EXISTS `OPTION_SUGGESTIONS_DATA` (
  `CODE` varchar(100) DEFAULT NULL,
  `INSTRUMENT` varchar(10) DEFAULT NULL,
  `EXPIRY_DATE` date DEFAULT NULL,
  `STRIKE_PRICE` double DEFAULT NULL,
  `OPTION_TYPE` varchar(10) DEFAULT NULL,
  `OPTION_PRICE` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `PAYMENT_DETAILS`
--

CREATE TABLE IF NOT EXISTS `PAYMENT_DETAILS` (
  `NO_OF_STOCKS` int(10) DEFAULT NULL,
  `NO_OF_MONTHS` varchar(10) DEFAULT NULL,
  `AMOUNT` double DEFAULT NULL,
  `LINK` varchar(200) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RISK_RETURN_MATRIX`
--

CREATE TABLE IF NOT EXISTS `RISK_RETURN_MATRIX` (
  `CODE` varchar(100) NOT NULL DEFAULT '',
  `TYPE_3M` varchar(8) DEFAULT NULL,
  `TYPE_6M` varchar(8) DEFAULT NULL,
  `TYPE_9M` varchar(8) DEFAULT NULL,
  `TYPE_12M` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `STOCK_DETAILS`
--

CREATE TABLE IF NOT EXISTS `STOCK_DETAILS` (
  `CODE` varchar(100) NOT NULL DEFAULT '',
  `NAME` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `STOCK_SIGNAL_DETAILS`
--

CREATE TABLE IF NOT EXISTS `STOCK_SIGNAL_DETAILS` (
  `CODE` varchar(100) NOT NULL DEFAULT '',
  `SIGNAL_DATE` date NOT NULL DEFAULT '0000-00-00',
  `SIGNAL_TYPE` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`CODE`,`SIGNAL_DATE`,`SIGNAL_TYPE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `STOCK_SIGNAL_DETAILS_BACK`
--

CREATE TABLE IF NOT EXISTS `STOCK_SIGNAL_DETAILS_BACK` (
  `CODE` varchar(100) NOT NULL DEFAULT '',
  `SIGNAL_DATE` date NOT NULL DEFAULT '0000-00-00',
  `SIGNAL_TYPE` varchar(15) NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `SUGGESTIONS_DATA`
--

CREATE TABLE IF NOT EXISTS `SUGGESTIONS_DATA` (
  `CODE` varchar(100) NOT NULL DEFAULT '',
  `SUGGESTION_TYPE` varchar(10) NOT NULL DEFAULT '',
  `SIGNAL_PRICE` double DEFAULT NULL,
  `SIGNAL_TYPE` varchar(15) NOT NULL DEFAULT '',
  PRIMARY KEY (`CODE`,`SUGGESTION_TYPE`,`SIGNAL_TYPE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `USER_DETAILS`
--

CREATE TABLE IF NOT EXISTS `USER_DETAILS` (
  `USER_ID` varchar(25) DEFAULT NULL,
  `USERNAME` varchar(25) DEFAULT NULL,
  `MAIL` varchar(50) NOT NULL DEFAULT '',
  `PHONE` varchar(20) DEFAULT NULL,
  `PASSWORD` varchar(100) DEFAULT NULL,
  `PLAN` varchar(20) DEFAULT NULL,
  `USERTYPE` varchar(10) DEFAULT NULL,
  `ACTIVE` varchar(2) DEFAULT NULL,
  `ACTIVATION_CODE` varchar(20) DEFAULT NULL,
  `CREATION_DATE` date DEFAULT NULL,
  `RENEWAL_DATE` date DEFAULT NULL,
  `EXPIRY_DATE` date DEFAULT NULL,
  `LAST_LOGIN_DATE` datetime DEFAULT NULL,
  `SEND_NOTIFICATION` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`MAIL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `USER_SIMULATION_DETAILS`
--

CREATE TABLE IF NOT EXISTS `USER_SIMULATION_DETAILS` (
  `USER_ID` varchar(25) NOT NULL DEFAULT '',
  `CODE` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`USER_ID`,`CODE`),
  KEY `USER_SIMULATION_DETAILS_1` (`USER_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `USER_TRADING_ACCOUNT_DETAILS`
--

CREATE TABLE IF NOT EXISTS `USER_TRADING_ACCOUNT_DETAILS` (
  `USER_ID` varchar(25) NOT NULL DEFAULT '',
  `CODE` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`USER_ID`,`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `WORLD_STOCK_DETAILS`
--

CREATE TABLE IF NOT EXISTS `WORLD_STOCK_DETAILS` (
  `CODE` varchar(100) DEFAULT NULL,
  `NAME` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `WORLD_STOCK_DETAILS_BACK`
--

CREATE TABLE IF NOT EXISTS `WORLD_STOCK_DETAILS_BACK` (
  `CODE` varchar(100) DEFAULT NULL,
  `NAME` varchar(100) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `WORLD_STOCK_PRICE`
--

CREATE TABLE IF NOT EXISTS `WORLD_STOCK_PRICE` (
  `CODE` varchar(100) NOT NULL DEFAULT '',
  `PRICE` double DEFAULT NULL,
  `CP` double DEFAULT NULL,
  PRIMARY KEY (`CODE`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `WORLD_STOCK_PRICE_BACK`
--

CREATE TABLE IF NOT EXISTS `WORLD_STOCK_PRICE_BACK` (
  `CODE` varchar(100) NOT NULL DEFAULT '',
  `PRICE` double DEFAULT NULL,
  `CP` double DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
